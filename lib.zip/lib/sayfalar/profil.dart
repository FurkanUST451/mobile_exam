import 'package:flutter/material.dart';
class Profil extends StatelessWidget {
  const Profil({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: [
            SizedBox(height: 200,),
            CircleAvatar(child: Icon(Icons.person),),
            SizedBox(height: 50),
            Text("Ad : Furkan Berk Usta"),
            Text("Bölüm: Yazılım Mühendisliği"),
          ],
        ),
      ),
    );
  }
}
